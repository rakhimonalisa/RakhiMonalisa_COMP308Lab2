// Set the 'development' environment configuration object
module.exports = {
    db: 'mongodb://localhost/plaxamana-lab2',
    sessionSecret: 'developmentSessionSecret'
};